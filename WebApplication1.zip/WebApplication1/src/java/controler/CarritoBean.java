/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.http.HttpServletResponse;

@Named
@SessionScoped
public class CarritoBean implements Serializable {

    private Carrito carrito = new Carrito();
    private Carrito ultimoPedido = new Carrito();
    private String userName;

    public String getUserName() {
        userName = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
        return userName;
    }

    public String agregarManual() {
        FacesContext ctx = FacesContext.getCurrentInstance();

        Long id = Long.parseLong(ctx.getExternalContext().getRequestParameterMap().get("id"));
        String nombre = ctx.getExternalContext().getRequestParameterMap().get("nombre");
        double precio = Double.parseDouble(ctx.getExternalContext().getRequestParameterMap().get("precio"));
        String categoria = ctx.getExternalContext().getRequestParameterMap().get("categoria");

        Producto p = new Producto(id, nombre, precio, "", categoria);
        carrito.agregarProducto(p, 1);

        // Permanecemos en la misma página
        return null;
    }

    public String comprar() {
        Set<String> categoriasRequeridas = new HashSet<>(Arrays.asList(
                "bolis", "libreta", "libro", "calculadora"// <-- ajusta según tus categorías
        ));

        if (!carrito.tieneTodasLasCategorias(categoriasRequeridas)) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Faltan productos en alguna categoría",
                            "Debes incluir al menos un producto de cada categoría antes de comprar."));
            return null; // permanece en la misma página
        }

        ultimoPedido = new Carrito();
        for (ItemCarrito item : carrito.getItems()) {
            ultimoPedido.agregarProducto(item.getProducto(), item.getCantidad());
        }

        // Si pasa la validación
        // ... (aquí procesas el pedido)
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Compra realizada con éxito", null));
        carrito = new Carrito(); // vaciar carrito después de comprar
        return "confirmacion"; // navegar a la página de confirmación
    }

public void generarPDFUltimoPedido() throws IOException {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    HttpServletResponse response = 
        (HttpServletResponse) facesContext.getExternalContext().getResponse();

    response.reset();
    response.setContentType("application/pdf");
    response.setHeader("Content-Disposition", "attachment; filename=\"pedido.pdf\"");

    try (OutputStream out = response.getOutputStream()) {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, out);
        document.open();

        document.add(new Paragraph("Resumen del Pedido", 
            FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));

        PdfPTable tabla = new PdfPTable(4);
        tabla.setWidthPercentage(100);
        tabla.addCell("Producto");
        tabla.addCell("Categoría");
        tabla.addCell("Cantidad");
        tabla.addCell("Subtotal (€)");

        for (ItemCarrito item : ultimoPedido.getItems()) {
            tabla.addCell(item.getProducto().getNombre());
            tabla.addCell(item.getProducto().getCategoria());
            tabla.addCell(String.valueOf(item.getCantidad()));
            tabla.addCell(String.format("%.2f", item.getSubtotal()));
        }

        document.add(tabla);
        document.add(new Paragraph("Total: " + ultimoPedido.getTotal() + " €"));
        document.close();
    }

    facesContext.responseComplete();
}


    public Carrito getCarrito() {
        return carrito;
    }

    public void agregar(Producto p) {
        carrito.agregarProducto(p, 1);
    }

    public void eliminar(Long id) {
        carrito.eliminarProducto(id);
    }

    public double getTotal() {
        return carrito.getTotal();
    }

    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

}
