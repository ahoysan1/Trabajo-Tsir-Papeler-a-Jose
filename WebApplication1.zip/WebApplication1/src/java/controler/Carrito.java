/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.inject.Named;
import javax.enterprise.context.Dependent;

/**
 *
 * @author ahoysan1
 */
@Named(value = "carrito")
@Dependent
public class Carrito {

    private List<ItemCarrito> items = new ArrayList<>();

    public Carrito() {

    }

    public void agregarProducto(Producto p, int cantidad) {
        for (ItemCarrito item : items) {
            if (item.getProducto().getId().equals(p.getId())) {
                item.setCantidad(item.getCantidad() + cantidad);
                return;
            }
        }
        items.add(new ItemCarrito(p, cantidad));
    }

    public boolean tieneTodasLasCategorias(Set<String> categoriasRequeridas) {
        // Conjunto para evitar duplicados
        Set<String> categoriasEnCarrito = new HashSet<>();

        // Recorremos los items del carrito y añadimos sus categorías
        for (ItemCarrito item : items) {
            categoriasEnCarrito.add(item.getProducto().getCategoria());
        }

        // Comprobamos si el carrito contiene todas las categorías requeridas
        return categoriasEnCarrito.containsAll(categoriasRequeridas);
    }

    public void eliminarProducto(Long id) {
        items.removeIf(item -> item.getProducto().getId().equals(id));
    }

    public double getTotal() {
        return items.stream().mapToDouble(ItemCarrito::getSubtotal).sum();
    }

    public List<ItemCarrito> getItems() {
        return items;
    }

}
