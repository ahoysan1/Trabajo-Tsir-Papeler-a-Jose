/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.io.Serializable;
import javax.annotation.ManagedBean;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

/**
 *
 * @author ahoysan1
 */
@Named(value = "navigationController")
@SessionScoped
public class NavigationController implements Serializable {
    private String id;
    private String name, pwd;
    private String producto = "bolis";
    public NavigationController() {
    }
    public void listener(ActionEvent event) {
        String clientId = event.getComponent().getClientId();
        int index = clientId.indexOf(":", 0);
        id = clientId.substring(index + 1);
    }
    public void listener(ValueChangeEvent e) {
        producto = e.getNewValue().toString();
    }
    public String action() {
        String nextPage;
        nextPage = "error";
        switch (id) {
            case "login":
                nextPage = "login";
                break;
            case "home":
                nextPage = "index";
                break;
            case "productos":
                nextPage = "productos";
                break;
            case "bolis":
                nextPage = "bolis";
                break;
            case "libros":
                nextPage = "libros";
                break;
            case "calculadoras":
                nextPage = "calculadoras";
                break;
            case "libretas":
                nextPage = "libretas";
                break;
        }
  
        return nextPage;
    }
    
    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().invalidateSession();
        return "/faces/index?faces-redirect=true";
    }
    
    public String index() {
        return "/faces/index?faces-redirect=true";
    }
        
    public String shoppingCart() {
        return "/faces/client/carrito?faces-redirect=true";
    }
    
    public String login() {
        return "/faces/glassfish_forms/login?faces-redirect=true";
    }
    
    public String store() {
        return "/faces/productos?faces-redirect=true";
    }
    
   
   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public String getProducto() {
        return producto;
    }
    public void setProducto(String producto) {
        this.producto = producto;
    }
}
