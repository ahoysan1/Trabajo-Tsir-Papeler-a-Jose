/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controler;

import java.io.Serializable;
import java.util.Locale;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.faces.event.ValueChangeEvent;

@Named
@SessionScoped
public class LocaleBean implements Serializable {
    private String locale = Locale.getDefault().toString();
    private String carrito;
    private String iniciarSesion;
    private String productos;
    private String mensajeIndex;
    private String volverPaginaPrincipal;
    private String cerrarSesion;
    private String verBolis;
    private String verLibros;
    private String verLibretas;
    private String verCalculadoras;
    private String agregarCarrito;
    private String calculadoraBlanca;
    private String calculadoraCasio;
    private String nombreUsuario;
    private String contrasena;
    private String holaIniciaSesion;
    private String eliminar;
    private String total;
    private String comprar;

    public String getEliminar() {
        return eliminar;
    }

    public void setEliminar(String eliminar) {
        this.eliminar = eliminar;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getComprar() {
        return comprar;
    }

    public void setComprar(String comprar) {
        this.comprar = comprar;
    }
    
    

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getHolaIniciaSesion() {
        return holaIniciaSesion;
    }

    public void setHolaIniciaSesion(String holaIniciaSesion) {
        this.holaIniciaSesion = holaIniciaSesion;
    }
    
    

    public String getCalculadoraBlanca() {
        return calculadoraBlanca;
    }

    public void setCalculadoraBlanca(String calculadoraBlanca) {
        this.calculadoraBlanca = calculadoraBlanca;
    }

    public String getCalculadoraCasio() {
        return calculadoraCasio;
    }

    public void setCalculadoraCasio(String calculadoraCasio) {
        this.calculadoraCasio = calculadoraCasio;
    }

    public String getAgregarCarrito() {
        return agregarCarrito;
    }

    public void setAgregarCarrito(String agregarCarrito) {
        this.agregarCarrito = agregarCarrito;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public void cambioIdioma(ValueChangeEvent e) {
        locale = e.getNewValue().toString();
    }

    public String getCarrito() {
        return carrito;
    }

    public void setCarrito(String carrito) {
        this.carrito = carrito;
    }
    
    public String getIniciarSesion() {
        return iniciarSesion;
    }

    public void setIniciarSesion(String iniciarSesion) {
        this.iniciarSesion = iniciarSesion;
    }

    public String getProductos() {
        return productos;
    }

    public void setProductos(String productos) {
        this.productos = productos;
    }

    public String getMensajeIndex() {
        return mensajeIndex;
    }

    public void setMensajeIndex(String mensajeIndex) {
        this.mensajeIndex = mensajeIndex;
    }

    public String getVolverPaginaPrincipal() {
        return volverPaginaPrincipal;
    }

    public void setVolverPaginaPrincipal(String volverPaginaPrincipal) {
        this.volverPaginaPrincipal = volverPaginaPrincipal;
    }

    public String getCerrarSesion() {
        return cerrarSesion;
    }

    public void setCerrarSesion(String cerrarSesion) {
        this.cerrarSesion = cerrarSesion;
    }

    public String getVerBolis() {
        return verBolis;
    }

    public void setVerBolis(String verBolis) {
        this.verBolis = verBolis;
    }

    public String getVerLibros() {
        return verLibros;
    }

    public void setVerLibros(String verLibros) {
        this.verLibros = verLibros;
    }

    public String getVerLibretas() {
        return verLibretas;
    }

    public void setVerLibretas(String verLibretas) {
        this.verLibretas = verLibretas;
    }

    public String getVerCalculadoras() {
        return verCalculadoras;
    }

    public void setVerCalculadoras(String verCalculadoras) {
        this.verCalculadoras = verCalculadoras;
    }
    
    
    
    
    
    
}
